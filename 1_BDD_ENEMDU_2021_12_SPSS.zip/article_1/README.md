# article_1
Actitudes y estereotipos de los ecuatorianos acerca de la participación de la mujer en la sociedad.
